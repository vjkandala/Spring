package com.example.springbasics.interfaces;

/**
 * Created by 478774 on 12/5/17.
 */
public interface HelloWorldInterface {

    void sayHello();
}
