package com.example.springbasics.Impl;

import com.example.springbasics.interfaces.HelloWorldInterface;

/**
 * Created by 478774 on 12/5/17.
 */
public class HelloWorldImpl implements HelloWorldInterface {
    @Override public void sayHello() {
        System.out.println("Hello, I am in Hello");
    }
}
