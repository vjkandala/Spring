package com.example.springbasics;

import com.example.springbasics.Impl.HelloWorldImpl;
import com.example.springbasics.client.HelloWorldClient;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Created by 478774 on 12/5/17.
 */
@Configuration
public class config {

    @Bean
    public HelloWorldImpl getHelloWorldImpl(){
        return new HelloWorldImpl();
    }

    @Bean
    public HelloWorldClient getHelloWorldClient(){
        return new HelloWorldClient();
    }

    public static void main(String args[]){
        AnnotationConfigApplicationContext context =
                new AnnotationConfigApplicationContext(config.class);
        HelloWorldClient client =  context.getBean(HelloWorldClient.class);
        client.sayHello();
    }



}
