package com.example.springbasics.client;

import com.example.springbasics.Impl.HelloWorldImpl;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * Created by 478774 on 12/5/17.
 */
public class HelloWorldClient {

    @Autowired
    HelloWorldImpl helloWorld;

    public void sayHello(){
        helloWorld.sayHello();;
    }
}
